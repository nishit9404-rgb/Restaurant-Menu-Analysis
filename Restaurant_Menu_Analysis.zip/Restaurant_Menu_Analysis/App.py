from data_loader import load_data
from analysis import add_profit_and_revenue, summarize_items, top_bottom_items
from visualization import plot_category_sales, plot_correlation

def main():
#Load & prepare data
    df = load_data("Data/menu.csv", "Data/sales.csv")
    df = add_profit_and_revenue(df)

#Summarize
    summary = summarize_items(df)
    print("\nSummary:\n", summary)

#Top & bottom sellers
    top, bottom = top_bottom_items(summary)
    print("\nTop 5 items:\n", top)
    print("\nLowest 5 items:\n", bottom)

#Visualizations
    plot_category_sales(summary)
    plot_correlation(summary)

if __name__ == "__main__":
    main()
