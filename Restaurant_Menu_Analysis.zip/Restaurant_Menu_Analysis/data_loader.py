#Load and merge menu and sales data
import pandas as pd

def load_data(menu_file, sales_file):
    menu_df = pd.read_csv(menu_file)
    sales_df = pd.read_csv(sales_file)
    df = pd.merge(sales_df, menu_df, on="item", how="inner")
    return df

