import pandas as pd

#Calculate profit margin and revenue
def add_profit_and_revenue(df):
    df["profit_margin"] = (df["selling_price"] - df["cost"]) / df["selling_price"]
    df["total_revenue"] = df["selling_price"] * df["quantity_sold"]
    return df

#Group by item & category
def summarize_items(df):
    return df.groupby(["item", "category"]).agg(
        total_quantity=("quantity_sold", "sum"),
        total_revenue=("total_revenue", "sum"),
        avg_profit_margin=("profit_margin", "mean")
    ).reset_index()

#Get top and bottom selling items
def top_bottom_items(summary_df, n=5):
    top = summary_df.nlargest(n, "total_quantity")
    bottom = summary_df.nsmallest(n, "total_quantity")
    return top, bottom
