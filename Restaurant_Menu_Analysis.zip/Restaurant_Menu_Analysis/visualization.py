import matplotlib.pyplot as plt
import seaborn as sns

def plot_category_sales(summary_df):
    category_sales = summary_df.groupby("category")["total_quantity"].sum()
    plt.figure(figsize=(7,5))
    sns.barplot(x=category_sales.index, y=category_sales.values, palette="viridis")
    plt.title("Sales Quantity by Menu Category")
    plt.xlabel("Menu Category")
    plt.ylabel("Total Quantity Sold")
    plt.show()

def plot_correlation(summary_df):
    plt.figure(figsize=(6,4))
    corr = summary_df[["total_quantity", "total_revenue", "avg_profit_margin"]].corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", linewidths=0.5)
    plt.title("Correlation Heatmap")
    plt.show()
